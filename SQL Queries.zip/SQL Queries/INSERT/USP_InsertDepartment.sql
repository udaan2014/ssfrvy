-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in department Table
-- ==============================================================================================================            
CREATE PROCEDURE USP_InsertDepartment
(
	--@DepartmentId varchar(50),
	@DepartmentName varchar(50),
	@DateOfCreation date
)
AS
BEGIN
	BEGIN TRY
		DECLARE @lastID varchar(50)
		DECLARE @deptID varchar(50)
		DECLARE @DepartmentId varchar(50)
		SET @lastID = ISNULL((SELECT MAX(DepartmentId) FROM [Department]), 'DEPT00')
		SET @lastID= SUBSTRING(@lastID,5,2)		
		SET @deptID=CAST(@lastID AS int) +1		
		SET @DepartmentId='DEPT' + RIGHT(('00'+@deptID),2)

		INSERT INTO [Department]([DepartmentId],[DepartmentName],[DateOfCreation] )
		VALUES (@DepartmentId,@DepartmentName,@DateOfCreation)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
