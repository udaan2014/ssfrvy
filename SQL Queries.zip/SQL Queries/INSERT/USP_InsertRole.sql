
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in Role Table
-- ==============================================================================================================          

CREATE PROCEDURE USP_InsertRole
(	
	@RoleType varchar(50),
	@Description varchar(255)	
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [Role]([RoleType],[Description])
		VALUES (@RoleType,@Description)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO       