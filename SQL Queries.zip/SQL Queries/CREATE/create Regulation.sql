
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables Regulation
-- ==============================================================================================================
CREATE TABLE [Regulation]
(
	[RegulationId] int IDENTITY(1,1),
	[RegulationName] varchar(50),
	[Description] varchar(255),
	[Status] varchar(50),
	[DateOfCreation] date DEFAULT GETDATE(),
	[DateOfModification] date DEFAULT GETDATE(),
	CONSTRAINT PK_Regulation_RegulationId PRIMARY KEY ([RegulationId])
)
GO