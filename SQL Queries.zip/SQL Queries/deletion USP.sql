-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows  of User Table
-- ==============================================================================================================    

CREATE PROCEDURE USP_DeleteUserData
(
	@UserId varchar(50)
)
AS
BEGIN
	BEGIN TRY
		DELETE [User] WHERE [UserId] = @UserId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows of Department table
-- ==============================================================================================================    

CREATE PROCEDURE USP_DeleteDepartmentData
(
	@DepartmentId varchar(50)
)
AS
BEGIN
	BEGIN TRY
		DELETE [Department] WHERE [DepartmentId] = @DepartmentId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows of Role Table
-- ==============================================================================================================    

CREATE PROCEDURE USP_DeleteRoleData
(
	@RoleId int
)
AS
BEGIN
	BEGIN TRY
		DELETE [Role] WHERE [RoleId] = @RoleId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows of Regulation Table
-- ==============================================================================================================    

CREATE PROCEDURE USP_DeleteRegulationData
(
	@RegulationId int
)
AS
BEGIN
	BEGIN TRY
		DELETE [Regulation] WHERE [RegulationId] = @RegulationId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows of RegulationDepartment Table
-- ==============================================================================================================    

CREATE PROCEDURE USP_DeleteRegulationDepartmentData
(
	@RegulationId int,
	@DepartmentId varchar(50)
)
AS
BEGIN
	BEGIN TRY
		DELETE [RegulationDepartment] WHERE [RegulationId]=@RegulationId AND [DepartmentId]=@DepartmentId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows of Comments Table
-- ==============================================================================================================    

CREATE PROCEDURE USP_CommentData
(
	@UserId varchar(50),
	@RegulationId int
)
AS
BEGIN
	BEGIN TRY
		DELETE [Comment] WHERE [UserId]= @UserId AND [RegulationId]= @RegulationId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO