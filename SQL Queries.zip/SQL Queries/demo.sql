
-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On :1-2-2018
-- Description: Created the Store Procedures for User Authentication during Login time
-- ==============================================================================================================
CREATE PROCEDURE USP_CheckUserLoginDetails
(
	@UserId varchar(50),
	@Password varchar(50)
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		SELECT * FROM [User] WITH(NOLOCK) WHERE [UserId]= @UserId AND [Password]= @Password
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END

-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On : 1-2-2018
-- Description: Created the Store Procedure returning the Role type of a particular user using his UserID

-- ==============================================================================================================
CREATE PROCEDURE USP_GetRoleAfterLogin
(
	@UserId varchar(50)
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		SELECT R.RoleType FROM [User] AS L INNER JOIN [Role] AS R ON  L.RoleId= R.RoleId AND L.UserId=@UserId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO

-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On : 1-2-2018
-- Description: Created the Store Procedure for Counting Acceptance

-- ==============================================================================================================
CREATE PROCEDURE USP_CountRegulationAcceptance
(
	@RegulationId int
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		SELECT COUNT(Acceptance) FROM [Comment] WITH(NOLOCK) WHERE Acceptance=1 AND [RegulationId]=@RegulationId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO

-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On : 1-2-2018
-- Description: Created the Store Procedure for Counting Rejection

-- ==============================================================================================================
CREATE PROCEDURE USP_CountRegulationRejection
(
	@RegulationId int
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		SELECT COUNT(Acceptance) FROM [Comment] WITH(NOLOCK) WHERE Acceptance=0 AND [RegulationId]=@RegulationId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO