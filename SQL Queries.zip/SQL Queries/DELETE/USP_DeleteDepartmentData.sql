-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Deleting Rows of Department table
-- ==============================================================================================================    

CREATE PROCEDURE USP_DeleteDepartmentData
(
	@DepartmentId varchar(50)
)
AS
BEGIN
	BEGIN TRY
		DELETE [Department] WHERE [DepartmentId] = @DepartmentId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO