-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from user table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectUserData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [UserId],
				[UserName],
				[Password],
				[RoleId],
				[DepartmentId],
				[DateOfJoining],
				[DateOfBirth],
				[EmailId],
				[Phonenumber],
				[Address],
				[SecretQuestion]
		FROM [User]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   