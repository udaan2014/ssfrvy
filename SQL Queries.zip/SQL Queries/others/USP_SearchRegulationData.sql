
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Searching for Particular Regulation
-- ==============================================================================================================    
CREATE PROCEDURE USP_SearchRegulationData
(
	@RegulationId int
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [RegulationId],
				[RegulationName],
				[Description],
				[Status],
				[DateOfCreation],
				[DateOfModification] 
		FROM [Regulation] WITH(NOLOCK) WHERE [RegulationId]=@RegulationId 
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   