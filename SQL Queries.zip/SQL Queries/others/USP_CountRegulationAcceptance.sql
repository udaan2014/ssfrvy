
-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On : 1-2-2018
-- Description: Created the Store Procedure for Counting Acceptance

-- ==============================================================================================================
CREATE PROCEDURE USP_CountRegulationAcceptance
(
	@RegulationId int
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		SELECT COUNT(Acceptance) FROM [Comment] WITH(NOLOCK) WHERE Acceptance=1 AND [RegulationId]=@RegulationId
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO