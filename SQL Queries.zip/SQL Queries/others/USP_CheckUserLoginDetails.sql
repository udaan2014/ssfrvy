
-- ==============================================================================================================

-- Author : Aromita Sen (666114)
-- Created On :1-2-2018
-- Description: Created the Store Procedures for User Authentication during Login time
-- ==============================================================================================================
CREATE PROCEDURE USP_CheckUserLoginDetails
(
	@UserId varchar(50),
	@Password varchar(50)
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		SELECT * FROM [User] WITH(NOLOCK) WHERE [UserId]= @UserId AND [Password]= @Password
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END