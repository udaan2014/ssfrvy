
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Regulation
-- ==============================================================================================================

CREATE PROCEDURE 
(
	@RegulationId int,
	@RegulationName varchar(50),
	@Description varchar(255),
	@Status varchar(50),
	@DateOfCreation date,
	@DateOfModification date
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Regulation] SET
		[RegulationName]=ISNULL(@RegulationName,RegulationName),
		[Description]= ISNULL(@Description,Description),
		[Status]= ISNULL(@Status,Status),	
		[DateOfCreation]= ISNULL(@DateOfCreation,DateOfCreation),
		[DateOfModification]=ISNULL(@DateOfModification,DateOfModification)		
		WHERE [RegulationId] = @RegulationId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO