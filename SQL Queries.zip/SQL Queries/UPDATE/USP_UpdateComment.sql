
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Comment
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateComment
(
	@UserId varchar(50),
	@RegulationId int,
	@Acceptance bit,
	@Description varchar(255),
	@DateOfCreation date,
	@DateOfModification date
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Comment] SET
		[Acceptance]=ISNULL(@Acceptance,Acceptance),
		[Description]=ISNULL(@Description,Description),
		[DateOfCreation]=ISNULL(@DateOfCreation,DateOfCreation),
		[DateOfModification]=ISNULL(@DateOfModification,DateOfModification)
		WHERE [UserId]=@UserId AND [RegulationId]=@RegulationId		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO